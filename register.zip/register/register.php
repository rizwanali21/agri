<html>
    <head>
        <title>Form Design</title>
        <link rel="styleSheet" href="FormAs.css">
        <style>
.error {color: #FF0000;}
</style>
    </head>
    <body>
    
        <form action="..\TestPhp.php" method="post">
            <div class="container">
              <h1>Sign Up</h1>
              <p>Please fill in this form to create an account.</p>
              <hr>
              <p><span class="error">* required field</span></p>
              <label for="email"><b>Email</b></label><span class="error">* </span>
              <input type="text" placeholder="Enter Email" name="email" required>

              <label for="user"><b>Username</b></label><span class="error">* </span>
      <input type="text" placeholder="UserName" name="user" required>
          
              <label for="psw"><b>Password</b></label><span class="error">* </span>
              <input type="password" placeholder="Enter Password" name="psw" required>
          
              <label for="psw-repeat"><b>Repeat Password</b></label><span class="error">* </span>
              <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
          
              <label>
                <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
              </label>
          
              <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>
          
              <div class="clearfix">
                <button type="button" class="cancelbtn">Cancel</button>
                <button type="submit" class="signupbtn" name="register">Sign Up</button>
              </div>
            </div>
          </form>
          
    </body>
</html>
